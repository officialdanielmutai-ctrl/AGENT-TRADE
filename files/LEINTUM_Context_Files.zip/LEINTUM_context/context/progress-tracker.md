# Progress Tracker

Update this file after every meaningful implementation change.

## Current Phase

- Pre-Phase 1 — planning and specification complete, no code written yet.

## Current Goal

- Begin Phase 1: build and test the Bridge in isolation, no MT5
  involved (see `context/specs/01-bridge-isolation.md`).

## Completed

- LEINTUM System Blueprint v1.0 — complete architecture, three-layer
  design, all 13 MQL5 modules specified, full JSON protocol (v1.0),
  six-phase build guide.
- EURUSD Engine indicator-free formula overhaul v1.0 — diagnostic of
  every replaced indicator, full math for DER, Hurst proxy, RBE, NPV,
  acceleration, IER, bar-energy divergence, VWAP value area, SDS,
  BQS, HTF structural bias, quantile overextension, cross-pair DER
  consensus, plus the `Defines.mqh` struct changes and a 10-step
  implementation checklist.
- Live one-week EURUSD market simulation (acting as an LLM trading
  desk) — validated the no-fixed-SL/TP, bar-anatomy-driven management
  protocol: 3 trades, 3 wins, 0 losses, +81.5 pips net, max drawdown
  12.9 pips.
- One-month backtest diagnostic — found regime-strength values
  reporting far outside the 0–100% range, corrupting downstream
  confidence calculations. Root cause: missing clamping on composite
  scores. Fix is specified as a mandatory step in Phase 2 (see
  `architecture.md` Invariant 8 and `code-standards.md`).
- Six-file context system populated for this project (this folder).

## In Progress

- None yet — no Phase 1 code has been started.

## Next Up

- Phase 1: Bridge in isolation — `npm init`, `server.js` with
  `/heartbeat` `/alert` `/status`, `llm.js`, `validator.js`,
  `logger.js`, draft `system_prompt.txt`, test against 5 sample
  payloads. Full detail in `context/specs/01-bridge-isolation.md`.

## Open Questions

- Exact MT5 broker has not been selected (Blueprint lists Exness, IC
  Markets, FXCM as candidates — confirm all 7 required symbols
  (EURUSD, GBPUSD, USDCHF, USDJPY, AUDUSD, XAUUSD, USOIL) are
  available before Phase 2).
- VPS vs. local-machine hosting for the Bridge is not finalised — a
  decision is only needed by Phase 6 (live deployment), but Phase 5's
  demo run should run wherever Phase 6 will run, to surface latency
  issues early.
- Macro calendar source for the hardcoded Phase 2.3 calendar (which
  provider/feed) is not specified in the Blueprint — needs a decision
  before Phase 2 step 2.3.
- Exact current Claude model string to put in `.env` should be
  confirmed against current Anthropic documentation at the time
  Phase 1 begins, rather than hardcoded from the Blueprint's
  reference (`claude-sonnet-4-20250514` was the reference at
  spec-writing time and may no longer be the current model).

## Architecture Decisions

- **No database.** State lives in MT5's own position table plus the
  JSONL session log — this is a single-operator system, not a
  multi-tenant SaaS product. (Rationale: avoids unnecessary
  infrastructure for a system with one user and one instrument.)
- **Clamping is mandatory on every composite score**, enforced at the
  point of computation in the MQL5 module, not downstream. (Rationale:
  direct fix for the one-month backtest's unclamped regime-strength bug.)
- **`HOLD_MANAGED` is the default exit basis**, not a fixed RR ratio.
  (Rationale: validated by the live one-week simulation's
  12.9-pip max drawdown with no fixed SL/TP.)
- **CPriceFabric centralises all OHLCV fetching** rather than letting
  each module call `Copy*` independently. (Rationale: eliminates
  duplicate fetches and the indicator buffer overhead this whole
  redesign exists to remove.)
- **The Bridge is intentionally "dumb."** No market interpretation
  logic lives in `bridge/` — all reasoning is either in MQL5 (sensing)
  or in Claude (deciding). (Rationale: keeps the three-layer
  separation in `architecture.md` enforceable and testable in isolation.)

## Session Notes

- This context folder was generated from two source documents: the
  LEINTUM Blueprint (architecture, protocol, build guide) and the
  EURUSD Engine Formula Overhaul (the underlying math, folded into
  `formulas.md` alongside the LEINTUM-specific v4 additions —
  SVR, HTF Flow Velocity, Cross-Pair Energy Field, HealthScore).
- When resuming a session, read `CLAUDE.md` first, then whichever
  phase spec in `context/specs/` matches "Next Up" above.
- The Phase 3 benchmark replay (Tuesday June 2 2026, 16:00, the
  1.16522 distribution-break bar) is the single most important
  acceptance test in the whole build — it is what separates "the
  system prompt works" from "the system prompt sounds plausible."
  Do not consider Phase 3 done without running it.
