# Code Standards

## General

- Each MQL5 module (`*.mqh`) does exactly one job, matching its name
  in `architecture.md` § System Boundaries — `RegimeDetector.mqh`
  computes regime, nothing else; it never reaches into
  `MomentumPhase.mqh`'s territory.
- Fix root causes, not symptoms. The regime-strength clamping bug
  found in the one-month backtest is the canonical example: the fix
  is clamping every normalised output at the point it's computed, not
  patching downstream consumers that received an out-of-range value.
- Do not mix sensing, transport, and decision concerns in one place.
  Formula modules sense. The Bridge transports. The LLM decides. The
  `DecisionExecutor` executes. Keep these boundaries exactly as
  defined in `architecture.md`.
- No live indicator handles anywhere in the engine (`iADX`, `iBands`,
  `iATR`, `iMA`, `iRSI`, `iMACD`, `iStochastic`). All signals derive
  from raw OHLCV via `CPriceFabric`. If you find yourself reaching for
  an indicator handle, you are solving the wrong problem — check
  `formulas.md` for the formula that replaces it.

## MQL5 (EA layer)

- All formula modules read OHLCV through `CPriceFabric` — never call
  `CopyOpen`/`CopyHigh`/`CopyLow`/`CopyClose`/`CopyTickVolume`
  directly inside a module. `Refresh()` runs once per `OnTick()`,
  before any module's `Update()`.
- Every normalised score (`strength`, `confidence`, `health_score`,
  `der`, `hurst`, any 0–1 or 0–100 output) is clamped to its defined
  range at the point of computation, before it is stored in a struct
  or written to the payload. This is non-negotiable — see
  `architecture.md` Invariant 8.
- Struct definitions live only in `Defines.mqh`. When a module's
  output shape changes, update `Defines.mqh` first, confirm it
  compiles with zero errors, then update the module logic — do not
  reshape a struct and change logic in the same step (this is Step 1
  of the formula-overhaul build sequence and the same discipline
  applies to all future module work).
- `MarketStatePackager.mqh` builds JSON via manual string
  concatenation with a fixed, validated field order — every field
  must appear in the same position on every call so the payload is
  diffable and the Bridge's expectations stay stable. Validate output
  against a JSON linter before considering a packager change done.
- `BridgeClient.mqh` is the only module that calls `WebRequest`. No
  other module talks to the network.
- `DecisionExecutor.mqh` is the only module that calls `OrderSend` /
  modifies or closes a position based on an LLM decision.
  `RiskManager.mqh` / `TradeHealthMonitor.mqh` is the only path that
  can close a position without an LLM decision (the hard HealthScore
  floor).
- Use `Print()` for Strategy Tester / Expert log diagnostics during
  development; gate verbose logging behind a `verbose` input so
  production runs don't flood the log.

## Node.js (Bridge layer)

- The Bridge has zero market-interpretation logic. `server.js`,
  `llm.js`, `validator.js`, `logger.js`, `fallback.js`, `telegram.js`
  each do one job; none of them reasons about price.
- Every LLM call goes through `llm.js` with an `AbortController`
  8-second timeout. On timeout or any non-schema-valid response,
  return the fallback HOLD response from `fallback.js` — never let an
  unhandled error reach the EA.
- Every LLM response is validated against the Zod schema in
  `validator.js` before it leaves the Bridge. A response that fails
  validation is treated as a failure, not "close enough" — fall back
  to HOLD.
- Every call (payload in, response out, timestamp, bar number) is
  appended to the day's JSONL log via `logger.js`, win or fail. Logs
  are append-only — never rewrite or truncate a log file in code.
- All configuration (API key, port, timeout, model name, log path,
  Telegram token/chat ID) comes from `.env` via `dotenv`. Never
  hardcode a secret, a model name, or a port number in source.
- Use `async/await` throughout; no unhandled promise rejections.
  Wrap the LLM call and the order-of-operations per request in
  try/catch with an explicit fallback path.
- Keep `server.js` a thin router — request handling, not business
  logic. Route handlers call into `llm.js`/`validator.js`/`logger.js`
  and return; they do not contain inline reasoning about what the
  response means.

## JSON Protocol

- Every payload and response includes `schema_version`. Treat the
  protocol as a contract between three independently-deployed
  components (EA, Bridge, LLM via system prompt) — a shape change on
  one side without a coordinated update on the others breaks the
  system silently.
- Field names and structure follow exactly what's documented in
  `architecture.md` and the Blueprint's JSON protocol section — do
  not introduce ad hoc fields without updating `Defines.mqh`,
  `validator.js`, and the system prompt's response-schema section
  together.
- `action` is a closed enum: `OPEN_BUY | OPEN_SELL | HOLD |
  CLOSE_ALL | CLOSE_PARTIAL`. `sl_basis`, `tp_basis`, and `urgency`
  are similarly closed enums — validate against the exact set, reject
  anything else.
- The LLM must never output text outside the JSON object. This is a
  system-prompt requirement (§5, response schema) enforced by Zod on
  the Bridge side as the second layer of defence.

## Styling (dashboard)

- CSS custom property tokens only — no hardcoded hex values in
  `viewer.html` / `live.html`. Follow the tokens and border-radius
  scale defined in `ui-context.md`.
- No build step for the dashboard. Plain HTML/CSS/JS, single files,
  deployable by opening in a browser or serving statically.

## File Organization

- `mt5/Experts/` — the single EA entry file only.
- `mt5/Include/LEINTUMEngine/` — all formula modules, the packager,
  the bridge client, the decision executor, the event monitor, and
  the risk manager. One file per responsibility, matching
  `architecture.md` exactly.
- `bridge/` — all Node.js transport code, the system prompt, and
  Bridge configuration. No market logic.
- `dashboard/` — monitoring tools only, read-only consumers of
  `logs/`.
- `tools/` — developer/testing utilities, never imported by
  production code (`server.js` or the EA).
- `logs/` — runtime output only, gitignored, never hand-edited.
- `context/` — documentation and spec files. Never application logic.
