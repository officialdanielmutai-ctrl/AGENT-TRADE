# AI Workflow Rules

## Approach

Build LEINTUM incrementally through the six sequential build phases
defined in `context/specs/00-build-plan.md` and its per-phase spec
files. Context files define what to build, how to build it, and the
current state of progress. Always implement against these specs — do
not infer or invent trading logic, JSON shape, or risk behaviour from
scratch. If a spec file doesn't cover what you're about to build,
stop and say so rather than guessing.

**Do not skip phases.** Each phase produces a working, independently
testable output and the next phase depends on the previous one being
genuinely done — not "mostly done." Phase 4 (execution layer and live
event system) is the most important quality gate before any live
account is touched; treat its verification checklist as
non-negotiable.

## Scoping Rules

- Work on one unit (one spec file, or one numbered step within a
  phase spec) at a time.
- Prefer small, verifiable increments over large speculative changes.
  A formula module, the Bridge's validator, and the dashboard viewer
  are three different units even if they all happen to touch "Phase
  2" loosely — implement and verify them separately.
- Do not combine unrelated system boundaries in a single
  implementation step: a change to `RegimeDetector.mqh` and a change
  to `llm.js` are not the same unit, even on the same day.
- Never write trading decision logic into the EA. If a task seems to
  require the EA to "decide" something beyond hard risk-limit
  enforcement, that's a sign the task is mis-scoped — re-read
  `architecture.md` Invariant 1 before proceeding.

## When to Split Work

Split an implementation step if it combines:

- MQL5 formula changes and Bridge/Node.js changes in the same step
- A struct change in `Defines.mqh` and the module logic that consumes
  the new struct fields (reshape first, confirm it compiles, then
  change logic — see `code-standards.md`)
- Multiple unrelated formula modules (e.g. `RegimeDetector` and
  `ConditionAssessor`) in one prompt
- System-prompt iteration and Bridge code changes — these are
  reviewed against different evidence (the benchmark replay vs.
  schema/timeout behaviour) and should be separable

If a change cannot be verified end to end quickly against its phase's
"done when" criteria, the scope is too broad — split it.

## Handling Missing Requirements

- Do not invent trading behaviour, risk thresholds, or formula
  constants not defined in `formulas.md` or the Blueprint. If a
  threshold isn't specified (e.g. a new classification cutoff), flag
  it as an open question rather than picking a plausible-looking
  number.
- If a requirement is ambiguous, resolve it in the relevant context
  file (`architecture.md`, `formulas.md`, or the active spec) before
  implementing — don't resolve it silently inside the code.
- If a requirement is missing, add it as an open question in
  `progress-tracker.md` before continuing.
- When the current model string, SDK version, or platform behavior is
  uncertain, check current Anthropic documentation rather than
  assuming — model identifiers and SDK details change over time and
  must not be hardcoded from memory.

## Protected Files

Do not modify the following unless explicitly instructed:

- `bridge/system_prompt.txt` — this is iterated deliberately against
  the benchmark replay (Phase 3), not edited incidentally while
  working on something else. Log every change in
  `docs/SYSTEM_PROMPT_NOTES.md`.
- `mt5/Include/LEINTUMEngine/Defines.mqh` — struct changes ripple
  across every module; treat changes here as their own reviewed unit.
- `logs/*.jsonl` — runtime output, append-only, never hand-edited or
  rewritten by tooling.
- `.env` — configuration, never committed, never edited by an agent
  without explicit instruction (secrets live here).

## Keeping Docs in Sync

Update the relevant context file whenever implementation changes:

- The three-layer boundaries or folder structure → `architecture.md`
- Any formula, threshold, or classification rule → `formulas.md`
- The JSON payload/response shape → `architecture.md` (protocol
  section) **and** `code-standards.md`, together, with a
  `schema_version` bump
- Dashboard tokens, layout, or new monitoring views → `ui-context.md`
- Any new convention or rule discovered mid-build → `code-standards.md`

## Verification Gate — the Phase 3 Benchmark

Before Phase 3 is considered complete, the system must pass the
following test (the canonical quality gate for the intelligence
layer):

Send the LLM the Tuesday 16:00, June 2 2026 payload — the bar where
four failed tests of 1.16522 were followed by a distribution break on
volume drop. Ask: what do you see, what would you do?

- **Pass:** the response cites the distribution ceiling, the volume
  character, and the failed bullish tests, and recommends a SELL with
  `HOLD_MANAGED` exits.
- **Fail:** the response fires a BUY based on the DER reading alone
  and ignores bar anatomy — the system prompt needs another
  iteration before continuing.

This test requires the LLM to read bar anatomy over formula outputs,
weigh session character, and reason like a desk rather than a rule
engine. Passing it means the intelligence layer is operational.

## Before Moving to the Next Unit

1. The current unit works end to end within its defined scope.
2. No invariant defined in `architecture.md` was violated.
3. The unit's specific "done when" condition (from its phase spec
   file) is met — not a loose approximation of it.
4. `progress-tracker.md` reflects the completed work.
5. For MQL5 changes: the EA compiles with zero errors and Strategy
   Tester output is reviewed, not just assumed correct.
6. For Bridge changes: `node tools/prompt_tester.js` (or the
   equivalent phase test) passes against the relevant sample payloads.
