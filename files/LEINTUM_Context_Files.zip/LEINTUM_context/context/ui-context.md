# UI Context

LEINTUM has no end-user product surface. The "UI" here is two
internal monitoring tools — `dashboard/viewer.html` (static session
log review) and `dashboard/live.html` (real-time WebSocket view) —
plus Telegram push notifications. Keep these lean: vanilla HTML/CSS/
JS, no build step, no framework, no component library. A trading
operator opens these to make a fast go/no-go read, not to admire
design.

## Theme

Dark technical workspace — consistent with the trading-desk context.
Near-black background, layered surfaces, restrained accent colours
used only where they carry meaning (win/loss/hold, health score
bands, session state). No light mode needed.

## Colors

All values below are CSS custom properties — no hardcoded hex values
in `viewer.html` / `live.html`.

| Role | CSS Variable | Suggested value |
|---|---|---|
| Page background | `--bg-base` | `#0b0d10` |
| Surface (cards/rows) | `--bg-surface` | `#15181d` |
| Primary text | `--text-primary` | `#e8eaed` |
| Muted text | `--text-muted` | `#8a8f98` |
| Border | `--border-default` | `#262b33` |
| Win / profitable close | `--state-win` | `#2fae66` |
| Loss / unprofitable close | `--state-loss` | `#d24b4b` |
| HOLD / no action | `--state-hold` | `#5a6472` |
| SPIKE / blocked session | `--state-warn` | `#e0a23b` |
| Primary accent (links, active row) | `--accent-primary` | `#3d8bfd` |

## Typography

| Role | Font | Variable |
|---|---|---|
| UI text | System sans stack (`-apple-system, Segoe UI, Roboto, sans-serif`) | `--font-sans` |
| Payload / reasoning / JSON | Monospace (`ui-monospace, SFMono-Regular, Menlo, monospace`) | `--font-mono` |

Reasoning chains, JSON payloads, and conviction/health numbers always
render in `--font-mono` — this is operational data the trader is
scanning for precision, not marketing copy.

## Border Radius

| Context | Class/value |
|---|---|
| Inline badges (state, action) | `4px` |
| Cards / log rows | `8px` |
| Modals (decision detail expand) | `12px` |

## Component Library

None. Plain HTML/CSS/JS only — `viewer.html` reads the JSONL log
client-side (or via a tiny static fetch), `live.html` connects to
`ws_server.js`. No React, no Tailwind compiler step — this keeps the
dashboard a single deployable file per the architecture's "no DB,
no framework" principle.

## Layout Patterns

- **Session log viewer (`viewer.html`):** single-column scrollable
  list, most recent decision at top. Each row: timestamp, bar number,
  action badge (colour-coded), conviction value, one-line reasoning
  summary. Click/tap a row to expand the full reasoning chain,
  supporting factors, concerns, and the raw payload/response JSON.
- **Live dashboard (`live.html`):** top bar — connection status
  (Bridge reachable / unreachable), current session state badge
  (SPIKE/HOT/NORMAL/QUIET). Below: current open positions as cards,
  each showing direction, entry, live PnL in pips, and HealthScore as
  a coloured bar (green 60–100, amber 25–59, red <25 matching the
  HealthScore action thresholds in `formulas.md`). Last decision and
  its reasoning summary pinned at the bottom, updating on each
  heartbeat/alert via WebSocket push.
- **Badges:** action (`OPEN_BUY`/`OPEN_SELL`/`HOLD`/`CLOSE_ALL`/
  `CLOSE_PARTIAL`), session state, and HealthScore band all use the
  same small rounded-badge pattern with the state colour tokens above
  — consistency here is what makes a 5-minute end-of-day review fast.

## Icons

Minimal — text/badge driven rather than icon driven. If icons are
needed for connection status or alert type, use a single consistent
inline-SVG set (no icon font, no extra dependency) at `16px` for
inline badges.
