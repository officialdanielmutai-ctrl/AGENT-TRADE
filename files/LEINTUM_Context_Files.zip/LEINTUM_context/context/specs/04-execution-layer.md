# Unit 04: Execution Layer and Live Event System

## Goal

Build the execution layer and the real-time event system: LLM
decisions actually place/modify/close orders, intra-bar alerts fire
on registered conditions, the hard HealthScore floor enforces itself
regardless of LLM reachability, and the monitoring tools (log viewer,
Telegram) are live. This phase is the most important quality gate
before live deployment — do not relax its verification checklist.

## Design

`DecisionExecutor.mqh` is the only module that calls `OrderSend`
based on an LLM decision. `EventTriggerMonitor.mqh` checks registered
conditions on every tick and fires a targeted alert the moment one
trips — it does not wait for bar close. The HealthScore floor in
`TradeHealthMonitor.mqh` / `RiskManager.mqh` can close a position
without LLM involvement; this is the one execution path that bypasses
the "LLM decides" invariant by design (architecture.md Invariant 1
exception).

## Implementation

### 4.1 Write `DecisionExecutor.mqh`
Response parser, hard limit enforcement, order placement. Conviction
below 0.50 is rejected and logged, not silently ignored. Spread check
blocks entry when spread exceeds the configured limit.

### 4.2 Write `EventTriggerMonitor.mqh`
Register watch conditions per `architecture.md` (HealthScore < 50 /
< 25, SVR crosses 2.5, regime change, correlated-pair energy flip or
velocity reversal, 1×SL / 2×SL profit crossings). Check on every
tick. Manually trigger a `REGIME_CHANGE` condition in the tester and
confirm a management alert fires within the same bar with the LLM
response received and acted on.

### 4.3 Wire the full management cycle
Health score → alert → LLM response → execution, end to end. On a
test position: HealthScore < 25 triggers emergency close.
SL tightens automatically at HealthScore 25–50. BE lock fires at
1R profit.

### 4.4 Build the session log viewer
`dashboard/viewer.html` per `ui-context.md` — opens in browser, reads
the JSONL log, shows each decision with reasoning, outcome, and
colour-coding. An analyst should be able to review the day in under 5
minutes.

### 4.5 Build Telegram alerts
`bridge/telegram.js` — trade open/close, SPIKE state, Bridge-down
notifications. Test notification received on phone within 5 seconds
of trigger.

## Dependencies

- Telegram Bot API token (from `t.me/BotFather`) — add to `.env`
- No new MQL5 or Node packages beyond what Phases 1–2 already installed

## Verify when done

- [ ] `OPEN_SELL` with conviction 0.82 places a market SELL;
      conviction 0.42 is rejected and logged; spread check blocks
      entry when spread exceeds the limit
- [ ] Manually triggering `REGIME_CHANGE` in the tester fires a
      management alert within the same bar, and the LLM response is
      received and acted on
- [ ] On a test position: HealthScore < 25 triggers emergency close;
      SL tightens automatically at HealthScore 25–50; BE lock fires
      at 1R profit
- [ ] `dashboard/viewer.html` opens in browser, reads the JSONL log,
      and an analyst can review a full day's decisions in under 5
      minutes
- [ ] A Telegram test notification is received within 5 seconds of
      trigger
- [ ] No invariant in `architecture.md` is violated — specifically,
      the only execution path that bypasses LLM authorisation is the
      HealthScore hard floor
