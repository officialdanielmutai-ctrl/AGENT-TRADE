# Unit 02: MT5 Formula Layer

## Goal

Port all formula modules into MQL5 and prove they produce correct,
clamped output on historical data — no Bridge calls, no execution
yet.

## Design

Every module reads OHLCV exclusively through `CPriceFabric`. Every
module's output structs match the updated `Defines.mqh` shapes in
`formulas.md`. Every composite score is clamped at the point of
computation (this phase is where the one-month backtest's clamping
bug must be fixed for good — see `architecture.md` Invariant 8).

## Implementation

### 2.1 Port all formula modules from the v4 spec to MQL5
Apply the Hurst-clamping fix and the general clamping discipline to
every normalised output across all modules (`RegimeDetector`,
`MomentumPhase`, `ConditionAssessor`, `ContextAnalyzer`,
`CorrelationMonitor`, `SessionProfile`). Full formulas in
`context/formulas.md`.

### 2.2 Write `MarketStatePackager.mqh`
JSON serialiser using manual string building with fixed field order
(MQL5 has no native JSON library — see `code-standards.md`).

### 2.3 Add `macro_calendar` field to the payload
Hardcode the economic calendar for the test week initially (June
1–5 2026) — `next_event`, `minutes_to_event`, `tier` for all known
releases. (Open question: production calendar source — see
`progress-tracker.md`.)

### 2.4 Write `TradeHealthMonitor.mqh`
5-component HealthScore (A+B+C+D+E, 0–100) per `formulas.md`.

### 2.5 Run Strategy Tester on June 1–5 2026
Review 20 bars of payloads manually for correctness.

## Dependencies

- None beyond the MT5/MQL5 toolchain already available — this phase
  is pure MQL5, no new packages.

## Verify when done

- [ ] All modules compile with zero errors
- [ ] Strategy Tester log shows correct regime/momentum/phase output
      on historical data — specifically, regime strength stays within
      0–100% across the full test run (the original bug is fixed)
- [ ] On each bar, `Print()` from `MarketStatePackager.mqh` outputs a
      valid JSON string — paste into a JSON linter, zero errors
- [ ] Payload includes `next_event`, `minutes_to_event`, `tier` for
      all known releases in the test week
- [ ] `HealthScore` updates correctly on every bar; on a known
      v2-backtest losing trade, score drops below 25 before SL is hit
- [ ] Manual review of 20 bars of payloads from the June 1–5 2026
      Strategy Tester run: payloads are readable and complete, all
      conflicts are flagged, macro calendar is accurate
