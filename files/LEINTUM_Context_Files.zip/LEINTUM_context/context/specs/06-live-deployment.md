# Unit 06: Live Deployment

## Goal

Move the proven system to a live account with conservative position
sizing, full monitoring, and a standing weekly review discipline.

## Design

This is an operations phase, not a feature-build phase. The build is
done; this unit is about deploying it responsibly and keeping it
observed.

## Implementation

### 6.1 Deploy the Bridge
On a VPS or dedicated machine co-located with MT5. Latency from MT5
to Bridge should be under 50ms (same machine = 0ms).

### 6.2 Set position sizing
0.5% risk per trade for the first month. With a $10,000 account and a
10-pip average SL, 0.5% = $5 risk ≈ 0.05 lots — deliberately tiny.
Grow size only after one month of live data confirms the system.

### 6.3 Enable PM2 monitoring
Set up `pm2-logrotate`. Bridge stays alive across reboots; logs don't
fill the disk.

### 6.4 Set Telegram alerts for all critical events
No silent failures — the operator knows immediately when something
happens.

### 6.5 Weekly system prompt review
Compare decisions vs. outcomes. The system prompt is a living
document — it improves with data, same discipline as Phases 3 and 5.

## Dependencies

- VPS (if not already provisioned — Vultr, DigitalOcean, or Contabo,
  $5–10/month) — only needed if MT5 + Bridge must run 24/5 without a
  personal machine staying on
- Live MT5 account with deposit

## Verify when done

- [ ] Bridge-to-MT5 latency under 50ms
- [ ] Position sizing confirmed at 0.5% risk per trade
- [ ] PM2 keeps the Bridge alive across a test reboot; `pm2-logrotate`
      confirmed active
- [ ] Telegram alerts fire for all critical events with no silent
      failure observed in the first week
- [ ] First weekly system-prompt review completed and logged in
      `docs/SYSTEM_PROMPT_NOTES.md`

## The one measure of readiness before going live

Every prior phase's "done when" checklist is fully checked — Phase 4
in particular, since it is the non-negotiable quality gate per
`ai-workflow-rules.md`. If any earlier checklist has an open item,
resolve it before completing this unit, regardless of how long the
demo run has been running.
