# Unit 00: Build Plan

This proves the system was designed before the first prompt was sent.
The order below is fixed by dependency: the Bridge must reason
correctly in isolation before it's trusted with live MT5 payloads;
formulas must be correct before they're transmitted; transport must
be proven before execution is wired; execution must be proven on a
demo account before any live capital is at risk.

| Phase | Name | Produces | Depends on |
|---|---|---|---|
| 1 | Bridge in isolation | A working Express server that calls Claude, validates the response, and logs it — tested with 5 sample payloads, no MT5 involved | Nothing — first unit |
| 2 | MT5 formula layer | All 13 MQL5 modules compiling and producing correct, clamped output on historical data, including a working JSON packager | Nothing structurally, but the JSON shape it produces must match what Phase 1's `validator.js` expects |
| 3 | Connect MT5 to Bridge | Payloads flowing end to end from EA → Bridge → Claude → EA, decisions logged but not executed; system prompt iterated until it passes the benchmark replay | Phase 1 + Phase 2 |
| 4 | Execution layer and live event system | Orders actually placed/modified/closed from LLM decisions; intra-bar alerts wired; HealthScore-driven hard exits; dashboard and Telegram alerts live | Phase 3 |
| 5 | Demo account forward test | 2 weeks of live-market, paper-sized trading proving stability, drawdown, and reasoning quality | Phase 4 |
| 6 | Live deployment | Production-sized, monitored, continuously reviewed live system | Phase 5 |

Each phase has its own spec file in this folder:
`01-bridge-isolation.md`, `02-mt5-formula-layer.md`,
`03-connect-bridge.md`, `04-execution-layer.md`,
`05-demo-forward-test.md`, `06-live-deployment.md`.

Read `context/progress-tracker.md` to see which phase is current
before starting work.
