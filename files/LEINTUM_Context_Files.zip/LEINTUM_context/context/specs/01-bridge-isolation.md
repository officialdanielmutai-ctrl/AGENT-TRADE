# Unit 01: Bridge in Isolation

## Goal

Build and prove the Node.js Bridge as a standalone service — no MT5
involved — so the transport and intelligence layers are verified
before any market data flows through them.

## Design

Single-file-deployable Express server per `architecture.md`. No
market logic here — see `code-standards.md` § Node.js. All
configuration via `.env`.

## Implementation

### 1.1 Initialise the project
`npm init -y && npm install express @anthropic-ai/sdk zod dotenv jsonlines pm2`
in `bridge/`.

### 1.2 `server.js`
Express app with three routes: `POST /heartbeat`, `POST /alert`,
`GET /status`. `/status` returns `{ ok: true }`.

### 1.3 `llm.js`
Anthropic API caller. Wraps the call in an `AbortController` with an
8-second timeout. On timeout or error, returns the fallback HOLD
response from `fallback.js` rather than throwing. Reads the model
name from `.env` — never hardcode a model string (check current
Claude Platform docs for the recommended model at implementation
time).

### 1.4 `validator.js`
Zod schema matching the LLM Decision Response schema in
`architecture.md` / the Blueprint's JSON protocol section exactly —
closed enums for `action`, `sl_basis`, `tp_basis`, `urgency`. A valid
response passes; a malformed response throws a `ZodError` that is
caught upstream and converted to a fallback HOLD.

### 1.5 `logger.js`
JSONL append writer. Each call (payload, response, timestamp, bar
number) appended as one line to `logs/session_YYYY-MM-DD.jsonl`.

### 1.6 `system_prompt.txt`
First draft of the full LEINTUM system prompt (sections 1–5: identity,
measurement framework, decision protocol, management protocol,
response schema) per `architecture.md`. This will evolve heavily in
Phase 3 — this draft only needs to produce coherent, schema-valid
output on the sample payloads below.

### 1.7 Sample payload testing
Write 5 sample payloads in `tools/sample_payloads/`: clear SELL,
clear BUY, mixed HOLD, SPIKE session, post-NFP trend. Test via
`node tools/prompt_tester.js`.

## Dependencies

- `express` — HTTP server
- `@anthropic-ai/sdk` — LLM API client
- `zod` — response schema validation
- `dotenv` — environment configuration
- `jsonlines` — session log writer
- `pm2` — process manager (installed now, used from Phase 6 onward)

## Verify when done

- [ ] Server starts on the configured port; `GET /status` returns `{ ok: true }`
- [ ] `callLLM(prompt, payload)` in `llm.js` returns parsed JSON or the fallback HOLD response — never throws uncaught
- [ ] A valid LLM response passes Zod validation; a deliberately malformed one throws `ZodError` and is caught
- [ ] Every test call is appended as one line to the day's JSONL log
- [ ] All 5 sample payloads produce a correct action with a coherent reasoning chain
- [ ] No API key, model name, or port number is hardcoded anywhere in source — all from `.env`
