# Unit 03: Connect MT5 to Bridge

## Goal

Get payloads flowing end to end — EA → Bridge → Claude → EA — with
decisions logged but **not executed**, and iterate the system prompt
until decision quality matches the documented professional-desk
benchmark. This is the single most important quality gate in the
entire build.

## Design

`BridgeClient.mqh` is the only MQL5 module that talks to the network.
No order placement happens in this phase — decisions are observed and
graded, not acted on.

## Implementation

### 3.1 Write `BridgeClient.mqh`
`WebRequest` HTTP POST to `/heartbeat`. Confirm the EA sends the
payload and the Bridge prints the received payload to console.

### 3.2 Enable live LLM calls
Log every response to the MT5 Expert log. On each Strategy Tester
bar, the LLM decision is printed. Actions are logged but **not**
executed.

### 3.3 Run the June 1–5 2026 replay
Review every decision against the live session narrative documented
in `progress-tracker.md` / the Blueprint's live simulation. At
minimum the replay must match: no BUY on Tuesday morning, SELL
entered around Tuesday afternoon, LONG on the Thursday bear trap,
SELL post-NFP.

### 3.4 Adjust the system prompt
Iterate `bridge/system_prompt.txt` until decision quality matches the
benchmark. Document every change in `docs/SYSTEM_PROMPT_NOTES.md`.
Run the canonical acceptance test from `ai-workflow-rules.md` § The
Phase 3 Benchmark (the Tuesday 16:00 June 2 2026 bar — four failed
tests of 1.16522 followed by a distribution break on volume drop).

## Dependencies

- None new — uses the Bridge from Phase 1 and the formula layer from
  Phase 2 as-is.

## Verify when done

- [ ] EA sends a payload to `/heartbeat`; Bridge prints the received
      payload to console
- [ ] On each Strategy Tester bar, the LLM decision is printed to the
      Expert log; actions are logged but not executed
- [ ] LLM decisions on the June 1–5 2026 replay align with the
      professional-desk benchmark (no BUY Tuesday morning, SELL
      Tuesday afternoon, LONG Thursday bear trap, SELL post-NFP)
- [ ] The Phase 3 benchmark acceptance test (Tuesday 16:00 June 2
      2026 bar) passes: response cites the distribution ceiling,
      volume character, and failed bullish tests, recommends SELL
      with `HOLD_MANAGED`
- [ ] Every system prompt change made during this phase is recorded
      in `docs/SYSTEM_PROMPT_NOTES.md`
