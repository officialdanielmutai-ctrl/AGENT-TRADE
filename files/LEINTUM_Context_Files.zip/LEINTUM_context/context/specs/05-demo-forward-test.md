# Unit 05: Demo Account Forward Test

## Goal

Run the complete system live on a demo account, real market, paper
sizing, for two weeks — and prove it is stable and the LLM's
reasoning quality holds up outside the curated June 1–5 2026 replay.

## Design

0.01 lots (minimum size) throughout. No code changes during the run
except documented system-prompt iterations based on evening review.
This phase produces evidence, not new features.

## Implementation

### 5.1 Connect to a demo account
0.01 lots minimum size. Run the full system live for 2 weeks.

### 5.2 Review the session log every evening
Annotate the LLM's reasoning quality. Identify the top 3 system
prompt weaknesses observed that day. Update and redeploy
`system_prompt.txt` as needed (log changes in
`docs/SYSTEM_PROMPT_NOTES.md`, same discipline as Phase 3).

### 5.3 Measure
Max drawdown per trade, average trade duration, win rate, decisions
per day.

### 5.4 Stress test
Disconnect the Bridge mid-session. Confirm the fallback HOLD fires
and the system recovers.

## Dependencies

- A demo MT5 account with all 7 required symbols available (EURUSD,
  GBPUSD, USDCHF, USDJPY, AUDUSD, XAUUSD, USOIL)
- Nothing new on the Node.js side

## Verify when done

- [ ] System runs 10 consecutive trading days without a Bridge crash
      or unhandled exception
- [ ] Top-3 system prompt weaknesses identified and addressed across
      the run, each change logged
- [ ] Max drawdown under 20 pips per trade
- [ ] Average 1–3 trades per day
- [ ] Reasoning quality acceptable on more than 85% of decisions
      (evening-review judgment call, documented per day)
- [ ] Bridge disconnect stress test: fallback HOLD fires within 8
      seconds, no unintended positions opened, Bridge reconnects and
      resumes cleanly on the next bar
